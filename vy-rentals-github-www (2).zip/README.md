# Vy Rentals — GitHub Pages Bundle

This folder is ready for GitHub Pages with a custom domain set to **www.vy-rentals.com**.

## Publish steps
1) Create a repo on GitHub (e.g., `vy-rentals-site`) and upload these files to the root.
2) Go to **Settings → Pages**:
   - Source: **Deploy from a branch**
   - Branch: **main** and **/(root)**
3) Save, wait ~1 minute, then you should see “Your site is live.”
4) Ensure **Custom domain** shows **www.vy-rentals.com** and **Enforce HTTPS** is checked.

## DNS (Cloudflare)
- **CNAME** `www` → `<your-username>.github.io`
- Optionally point apex (`vy-rentals.com`) using the four GitHub A records or a redirect to `www`.

_Last updated: 2025-10-07_
